require('dotenv').config();
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

const app = express();
app.use(cors());
app.use(express.json());

// Initialize Firebase Admin
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        })
    });
}
const adminAuth = admin.auth();
const adminDb = admin.firestore();

// Route: Set Custom Claims (Role assignment)
app.post('/api/auth/setCustomClaims', async (req, res) => {
    try {
        const { idToken, role } = req.body;
        const decodedToken = await adminAuth.verifyIdToken(idToken);
        const uid = decodedToken.uid;
        
        await adminAuth.setCustomUserClaims(uid, { role });
        
        return res.json({ success: true, message: `Role ${role} set for user ${uid}` });
    } catch (error) {
        console.error('Error setting custom claims:', error);
        return res.status(500).json({ error: error.message });
    }
});

// Route: Create Child Account
app.post('/api/auth/createChild', async (req, res) => {
    try {
        const { idToken, email, password, name, age } = req.body;

        const decodedToken = await adminAuth.verifyIdToken(idToken);
        const parentUid = decodedToken.uid;
        
        if (decodedToken.role !== 'parent' && decodedToken.role !== 'admin') {
            return res.status(403).json({ error: 'Unauthorized' });
        }

        const userRecord = await adminAuth.createUser({
            email,
            password,
            displayName: name,
        });

        const childUid = userRecord.uid;

        await adminAuth.setCustomUserClaims(childUid, { role: 'child' });

        await adminDb.collection('users').doc(childUid).set({
            email,
            role: 'child',
            status: 'approved',
            name,
            age,
            parentUid,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        await adminDb.collection('users').doc(parentUid).set({
            children: admin.firestore.FieldValue.arrayUnion(childUid)
        }, { merge: true });

        return res.json({ success: true, message: `Child created`, childUid });
    } catch (error) {
        console.error('Error creating child:', error);
        return res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Backend server listening on port ${PORT}`);
});
